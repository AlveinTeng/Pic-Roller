document.querySelector('.nav__example').addEventListener('click', () => {
  // console.log("clicked!")
  window.location = "./examples.html"
})